package com.finmid.fintech

import org.junit.jupiter.api.AfterAll
import org.junit.jupiter.api.BeforeAll
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.ActiveProfiles
import org.springframework.test.context.DynamicPropertyRegistry
import org.springframework.test.context.DynamicPropertySource
import org.testcontainers.containers.DockerComposeContainer
import org.testcontainers.containers.wait.strategy.Wait
import org.testcontainers.junit.jupiter.Testcontainers
import java.io.File
import java.time.Duration

@Testcontainers
@SpringBootTest
@ActiveProfiles("test")
abstract class IntegrationTest {

    companion object {
        private val environment = KDockerComposeContainer(File("src/test/resources/docker-compose-test.yml"))
            .withExposedService("postgres", 5432)
            .waitingFor("postgres", Wait.forListeningPort().withStartupTimeout(Duration.ofMinutes(2)))

        @JvmStatic
        @BeforeAll
        fun setUp(): Unit {
            environment.start()
        }

        @AfterAll
        @JvmStatic
        fun tearDown() {
            environment.stop()
        }

        @DynamicPropertySource
        @JvmStatic
        fun databaseProperties(registry: DynamicPropertyRegistry) {
            val postgresHost = environment.getServiceHost("postgres", 5432)
            val postgresPort = environment.getServicePort("postgres", 5432)

            registry.add("spring.datasource.url") {
                "jdbc:postgresql://$postgresHost:$postgresPort/testdb"
            }
            registry.add("spring.datasource.username") { "testuser" }
            registry.add("spring.datasource.password") { "testpass" }
            registry.add("spring.datasource.driver-class-name") { "org.postgresql.Driver" }
        }
    }
}

class KDockerComposeContainer(file: File) : DockerComposeContainer<KDockerComposeContainer>(file)
