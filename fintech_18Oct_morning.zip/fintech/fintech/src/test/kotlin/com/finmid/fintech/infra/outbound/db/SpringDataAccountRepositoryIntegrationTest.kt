package com.finmid.fintech.infra.outbound.db

import com.finmid.fintech.IntegrationTest
import com.finmid.fintech.domain.model.Account
import com.finmid.fintech.domain.model.AccountBalance
import com.finmid.fintech.domain.repository.AccountRepository
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import java.math.BigDecimal

class SpringDataAccountRepositoryIntegrationTest : IntegrationTest() {

    @Autowired
    lateinit var accountRepository: AccountRepository

    @Test
    fun `should save and retrieve account`() {
        // Given
        val account = Account(balance = AccountBalance(BigDecimal("500.00")))

        // When
        val savedAccount = accountRepository.save(account)
        val retrievedAccount = accountRepository.findById(savedAccount.id!!)

        // Then
        assertTrue(retrievedAccount.isPresent)
        assertEquals(savedAccount.getBalance(), retrievedAccount.get().getBalance())
    }
}
