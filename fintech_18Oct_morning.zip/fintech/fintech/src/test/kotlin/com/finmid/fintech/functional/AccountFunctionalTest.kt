package com.finmid.fintech.functional

import com.fasterxml.jackson.databind.ObjectMapper
import com.finmid.fintech.IntegrationTest
import com.finmid.fintech.application.accounts.dto.AccountDto
import com.finmid.fintech.infra.inbound.rest.CreateAccountHttpRequest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.http.MediaType
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders
import org.springframework.test.web.servlet.result.MockMvcResultMatchers.status
import org.springframework.transaction.annotation.Transactional
import java.math.BigDecimal

@AutoConfigureMockMvc
class AccountFunctionalTest : IntegrationTest() {

    @Autowired
    private lateinit var mockMvc: MockMvc

    @Autowired
    private lateinit var objectMapper: ObjectMapper

    @Test
    @Transactional
    fun `should create and fetch account through API`() {
        // Arrange: Create a new account request
        val initialBalance = BigDecimal("10.45")
        val createAccountRequest = CreateAccountHttpRequest(initialBalance)

        // Act: Create the account through the API
        val createResponse = mockMvc.perform(
            MockMvcRequestBuilders.post("/accounts")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(createAccountRequest))
        )
            .andExpect(status().isCreated)
            .andReturn()

        // Extract the account ID from the response
        val accountDto = objectMapper.readValue(createResponse.response.contentAsString, AccountDto::class.java)
        assertNotNull(accountDto.accountId) // Ensure the accountId is not null

        // Act: Fetch the account balance through the API
        val fetchResponse = mockMvc.perform(
            MockMvcRequestBuilders.get("/accounts/${accountDto.accountId}/balance")
                .accept(MediaType.APPLICATION_JSON)
        )
            .andExpect(status().isOk)
            .andReturn()

        // Assert: Validate the fetched account balance
        val fetchedAccountDto = objectMapper.readValue(fetchResponse.response.contentAsString, AccountDto::class.java)
        assertEquals(accountDto.accountId, fetchedAccountDto.accountId)
        assertEquals(0, initialBalance.compareTo(fetchedAccountDto.balance))
    }
}
