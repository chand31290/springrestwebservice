package com.finmid.fintech.functional

import com.fasterxml.jackson.databind.ObjectMapper
import com.finmid.fintech.IntegrationTest
import com.finmid.fintech.domain.model.Account
import com.finmid.fintech.domain.model.AccountBalance
import com.finmid.fintech.domain.repository.AccountRepository
import com.finmid.fintech.infra.inbound.rest.CreateTransactionRequest
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.http.MediaType
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders
import org.springframework.test.web.servlet.result.MockMvcResultMatchers.status
import org.springframework.transaction.annotation.Transactional
import java.math.BigDecimal
import kotlin.test.assertEquals

@AutoConfigureMockMvc
class TransactionFunctionalTest : IntegrationTest() {

    @Autowired
    private lateinit var mockMvc: MockMvc

    @Autowired
    private lateinit var objectMapper: ObjectMapper

    @Autowired
    private lateinit var accountRepository: AccountRepository

    @Test
    @Transactional
    fun `should create a transaction between two accounts`() {

        val fromAccount = Account(
            balance = AccountBalance(BigDecimal(1000))
        )

        val toAccount = Account(
            balance = AccountBalance(BigDecimal(1000))
        )

        val savedFromAccount = accountRepository.save(fromAccount)
        val savedToAccount = accountRepository.save(toAccount)

        // Create the transaction request
        val request = CreateTransactionRequest(
            fromAccountId = savedFromAccount.id!!.value,
            toAccountId = savedToAccount.id!!.value,
            amount = BigDecimal("100.00")
        )

        // Perform the request
        mockMvc.perform(
            MockMvcRequestBuilders.post("/transactions")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request))
        ).andExpect(status().isCreated)

        val fromAccountBalanceAfterTxn = accountRepository.findById(savedFromAccount.id!!).get().getBalance()
        val toAccountBalanceAfterTxn = accountRepository.findById(savedToAccount.id!!).get().getBalance()

        assertEquals(0, BigDecimal(900).compareTo(fromAccountBalanceAfterTxn.value))
        assertEquals(0, BigDecimal(1100).compareTo(toAccountBalanceAfterTxn.value))
    }
}