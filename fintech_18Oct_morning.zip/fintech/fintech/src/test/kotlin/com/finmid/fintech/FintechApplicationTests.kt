package com.finmid.fintech

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.context.annotation.Import

@Import(TestcontainersConfiguration::class)
@SpringBootTest
class FintechApplicationTests {

	@Test
	fun contextLoads() {
	}

}
