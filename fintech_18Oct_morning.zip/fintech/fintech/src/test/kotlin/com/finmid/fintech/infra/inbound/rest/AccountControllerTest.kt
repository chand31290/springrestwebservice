package com.finmid.fintech.infra.inbound.rest


import com.finmid.fintech.application.accounts.CreateAccountUseCase
import com.finmid.fintech.application.accounts.FetchAccountBalanceUseCase
import com.finmid.fintech.application.accounts.dto.AccountDto
import com.finmid.fintech.domain.exception.AccountNotFoundException
import com.finmid.fintech.domain.model.AccountId
import com.ninjasquad.springmockk.MockkBean
import io.mockk.every
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest
import org.springframework.http.MediaType
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post
import org.springframework.test.web.servlet.result.MockMvcResultMatchers.*
import java.math.BigDecimal
import java.util.UUID

@WebMvcTest(AccountController::class)
class AccountControllerTest {

    @Autowired
    private lateinit var mockMvc: MockMvc

    @MockkBean
    private lateinit var createAccountUseCase: CreateAccountUseCase

    @MockkBean
    private lateinit var fetchAccountBalanceUseCase: FetchAccountBalanceUseCase

    private lateinit var accountId: UUID
    private lateinit var accountDto: AccountDto

    @BeforeEach
    fun setUp() {
        accountId = UUID.randomUUID()
        accountDto = AccountDto(accountId, BigDecimal("10.75"))
    }

    @Test
    fun `should create an account`() {
        // Arrange
        val requestBody = """{ "initialBalance": "${accountDto.balance}" }"""

        every { createAccountUseCase(any()) } returns accountDto

        // Act & Assert
        mockMvc.perform(post("/accounts")
            .contentType(MediaType.APPLICATION_JSON)
            .content(requestBody))
            .andExpect(status().isCreated)
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.accountId").value(accountId.toString()))
            .andExpect(jsonPath("$.balance").value(accountDto.balance.toString()))
    }

    @Test
    fun `should fetch account balance`() {
        // Arrange
        every { fetchAccountBalanceUseCase(AccountId(accountId)) } returns accountDto

        // Act & Assert
        mockMvc.perform(get("/accounts/${accountId}/balance"))
            .andExpect(status().isOk)
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.accountId").value(accountId.toString()))
            .andExpect(jsonPath("$.balance").value(accountDto.balance.toString()))
    }

    @Test
    fun `should return 404 when account is not found for balance check`() {

        // Arrange
        val invalidAccountId = UUID.randomUUID()
        every { fetchAccountBalanceUseCase.invoke(AccountId(invalidAccountId))} throws
            AccountNotFoundException("Account not found")

        // Act & Assert
        mockMvc.perform(get("/accounts/$invalidAccountId/balance")
            .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNotFound)
    }
}
