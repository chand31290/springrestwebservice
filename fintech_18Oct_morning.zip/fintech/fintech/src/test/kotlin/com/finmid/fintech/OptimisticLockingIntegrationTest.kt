package com.finmid.fintech

import com.finmid.fintech.domain.model.Account
import com.finmid.fintech.domain.model.AccountBalance
import com.finmid.fintech.domain.repository.AccountRepository
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.junit.jupiter.SpringExtension
import org.springframework.transaction.annotation.Transactional
import java.math.BigDecimal
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

@ExtendWith(SpringExtension::class)
class OptimisticLockingIntegrationTest : IntegrationTest() {

    @Autowired
    lateinit var accountRepository: AccountRepository

    @Test
    @Transactional
    fun testOptimisticLocking() {
        // Create an account with an initial balance
        val account = Account(balance = AccountBalance(BigDecimal("100.00")))
        accountRepository.save(account)

        // Number of concurrent threads
        val numThreads = 10
        val executor: ExecutorService = Executors.newFixedThreadPool(numThreads)
        val latch = CountDownLatch(numThreads)

        // Use a shared variable to track the exception status
        val exceptions = mutableListOf<Exception>()

        // Define the runnable task for concurrent execution
        val runnable = Runnable {
            try {
                // Fetch the account and update its balance
                val fetchedAccount = accountRepository.findById(account.id!!).get()
                // Attempt to change the balance
                fetchedAccount.getBalance() = fetchedAccount.balance.add(BigDecimal("50.00")) // Increment by 50.00
                accountRepository.save(fetchedAccount)
            } catch (e: Exception) {
                // Store the exception for later verification
                exceptions.add(e)
            } finally {
                latch.countDown() // Count down the latch
            }
        }

        // Submit the task to the executor
        repeat(numThreads) {
            executor.submit(runnable)
        }

        // Wait for all threads to finish
        latch.await()
        executor.shutdown()

        // Check the final state of the account
        val finalAccount = accountRepository.findById(account.id!!).get()

        // Print out the balance for debugging
        println("Final account balance: ${finalAccount.balance}")

        // Assert that the balance is expected
        // If all 10 updates were successful, the balance should reflect the last successful transaction
        assertEquals(BigDecimal("100.00").add(BigDecimal("50.00")), finalAccount.balance) // Expecting initial balance + 50

        // Assert that optimistic locking exceptions occurred
        assertTrue(exceptions.isNotEmpty()) { "Expected optimistic locking exceptions but none were thrown." }
    }
}
