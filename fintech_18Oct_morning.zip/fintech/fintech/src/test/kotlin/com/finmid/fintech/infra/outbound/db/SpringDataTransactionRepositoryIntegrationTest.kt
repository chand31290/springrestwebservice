package com.finmid.fintech.infra.outbound.db

import com.finmid.fintech.IntegrationTest
import com.finmid.fintech.domain.model.Account
import com.finmid.fintech.domain.model.AccountBalance
import com.finmid.fintech.domain.model.Transaction
import com.finmid.fintech.domain.model.TransactionAmount
import com.finmid.fintech.domain.repository.AccountRepository
import com.finmid.fintech.domain.repository.TransactionRepository
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import java.math.BigDecimal

class SpringDataTransactionRepositoryIntegrationTest : IntegrationTest() {

    @Autowired
    lateinit var transactionRepository: TransactionRepository

    @Autowired
    lateinit var accountRepository: AccountRepository

    @Test
    fun `should save and retrieve transaction`() {
        // Given
        val fromAccount = Account(balance = AccountBalance(BigDecimal("1000.00")))
        val savedFromAccount = accountRepository.save(fromAccount)

        val toAccount = Account(balance = AccountBalance(BigDecimal("2000.00")))
        val savedToAccount = accountRepository.save(toAccount)

        val transaction = Transaction(
            amount = TransactionAmount(BigDecimal("100.00")),
            fromAccount = savedFromAccount,
            toAccount = savedToAccount
        )

        // When
        val savedTransaction = transactionRepository.save(transaction)
        val retrievedTransaction = transactionRepository.findById(savedTransaction.transactionId!!)

        // Then
        assertTrue(retrievedTransaction.isPresent)
        assertEquals(savedTransaction.amount, retrievedTransaction.get().amount)
        assertEquals(savedTransaction.fromAccount.id, retrievedTransaction.get().fromAccount.id)
        assertEquals(savedTransaction.toAccount.id, retrievedTransaction.get().toAccount.id)
    }
}
