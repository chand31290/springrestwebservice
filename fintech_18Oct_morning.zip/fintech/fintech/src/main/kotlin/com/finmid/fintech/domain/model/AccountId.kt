package com.finmid.fintech.domain.model

import java.util.UUID

data class AccountId(val value : UUID)
