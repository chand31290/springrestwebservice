package com.finmid.fintech.domain.exception

import java.lang.Exception

data class AccountNotFoundException(val reason: String): Exception()
