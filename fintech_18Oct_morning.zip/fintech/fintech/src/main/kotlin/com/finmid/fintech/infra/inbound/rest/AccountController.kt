package com.finmid.fintech.infra.inbound.rest

import com.finmid.fintech.application.accounts.CreateAccountUseCase
import com.finmid.fintech.application.accounts.FetchAccountBalanceUseCase
import com.finmid.fintech.application.accounts.dto.AccountDto
import com.finmid.fintech.domain.model.Account
import com.finmid.fintech.domain.model.AccountId
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import java.math.BigDecimal
import java.util.UUID

@RestController
@RequestMapping("/accounts")
class AccountController(
    private val createAccountUseCase: CreateAccountUseCase,
    private val fetchAccountBalanceUseCase: FetchAccountBalanceUseCase
) {

    @PostMapping
    fun createAccount(@RequestBody request: CreateAccountHttpRequest): ResponseEntity<AccountDto> {
        val account = createAccountUseCase(request.initialBalance)
        return ResponseEntity.status(HttpStatus.CREATED).body(account)
    }

    @GetMapping("/{accountId}/balance")
    fun getAccountBalance(@PathVariable accountId: UUID): ResponseEntity<AccountDto> {
        val balance = fetchAccountBalanceUseCase(AccountId(accountId))
        return ResponseEntity.ok(balance)
    }
}

data class CreateAccountHttpRequest(val initialBalance : BigDecimal?)