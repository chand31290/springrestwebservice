package com.finmid.fintech.domain.service

import com.finmid.fintech.domain.exception.AccountNotFoundException
import com.finmid.fintech.domain.model.AccountId
import com.finmid.fintech.domain.model.Transaction
import com.finmid.fintech.domain.model.TransactionAmount
import com.finmid.fintech.domain.repository.AccountRepository
import com.finmid.fintech.domain.repository.TransactionRepository
import org.springframework.stereotype.Service
import java.math.BigDecimal

@Service
class TransactionService(
    private val accountRepository: AccountRepository,
    private val transactionRepository: TransactionRepository
) {

    fun processTransaction(fromAccountId: AccountId, toAccountId: AccountId, amount: BigDecimal) {
        val fromAccount = accountRepository.findById(fromAccountId)
            .orElseThrow { AccountNotFoundException("Source account not found") }

        val toAccount = accountRepository.findById(toAccountId)
            .orElseThrow { AccountNotFoundException("Destination account not found") }

        val transactionAmount = TransactionAmount(amount)

        val transaction = Transaction(
            fromAccount = fromAccount,
            toAccount = toAccount,
            amount = transactionAmount
        )

        transaction.execute()

        accountRepository.save(fromAccount)
        accountRepository.save(toAccount)
        transactionRepository.save(transaction)
    }
}
