package com.finmid.fintech.jpa.repositories

import com.finmid.fintech.jpa.entities.AccountEntity
import org.springframework.data.jpa.repository.JpaRepository
import java.util.*

interface JpaAccountRepository : JpaRepository<AccountEntity, UUID>