package com.finmid.fintech.domain.model

import java.util.UUID

data class TransactionId (val value : UUID)