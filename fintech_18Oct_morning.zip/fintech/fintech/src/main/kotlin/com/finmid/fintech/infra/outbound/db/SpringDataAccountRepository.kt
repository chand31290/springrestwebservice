package com.finmid.fintech.infra.outbound.db

import com.finmid.fintech.domain.model.Account
import com.finmid.fintech.domain.model.AccountBalance
import com.finmid.fintech.domain.model.AccountId
import com.finmid.fintech.domain.repository.AccountRepository
import com.finmid.fintech.jpa.entities.AccountEntity
import com.finmid.fintech.jpa.repositories.JpaAccountRepository
import org.springframework.stereotype.Repository
import java.util.*

@Repository
class SpringDataAccountRepository(
    private val jpaAccountRepository: JpaAccountRepository
) : AccountRepository {

    override fun findById(accountId: AccountId): Optional<Account> {
        val accountEntity = jpaAccountRepository.findById(accountId.value)
        return accountEntity.map { toDomain(it) }
    }

    override fun save(account: Account): Account {
        val accountEntity = jpaAccountRepository.save(toEntity(account))
        return toDomain(accountEntity)
    }

    private fun toDomain(accountEntity: AccountEntity): Account {
        return Account(
            id = AccountId(accountEntity.accountId!!),
            balance = AccountBalance(accountEntity.balance)
        )
    }

    private fun toEntity(account: Account): AccountEntity {
        return AccountEntity(
            accountId = account.id?.value,
            balance = account.getBalance().value
        )
    }
}