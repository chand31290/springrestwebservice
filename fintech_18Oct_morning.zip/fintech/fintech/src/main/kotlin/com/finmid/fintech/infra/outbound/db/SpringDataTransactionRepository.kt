package com.finmid.fintech.infra.outbound.db

import com.finmid.fintech.domain.model.*
import com.finmid.fintech.domain.repository.TransactionRepository
import com.finmid.fintech.jpa.entities.AccountEntity
import com.finmid.fintech.jpa.entities.TransactionEntity
import com.finmid.fintech.jpa.repositories.JpaTransactionRepository
import org.springframework.stereotype.Repository
import java.util.Optional

@Repository
class SpringDataTransactionRepository(
    private val jpaTransactionRepository: JpaTransactionRepository,
) : TransactionRepository {
    override fun save(transaction: Transaction): Transaction {
        val savedTransaction = jpaTransactionRepository.save(toEntity(transaction))
        return transaction.copy(transactionId = TransactionId(savedTransaction.transactionId!!))
    }

    override fun findById(transactionId: TransactionId): Optional<Transaction> {
        return jpaTransactionRepository.findById(transactionId.value).map { toDomain(it) }
    }

    private fun toDomain(txnFromDatabase: TransactionEntity): Transaction = with(txnFromDatabase){
        Transaction(
            transactionId = TransactionId(transactionId!!),
            amount = TransactionAmount(amount),
            fromAccount = toAccountDomain(fromAccount!!),
            toAccount = toAccountDomain(toAccount!!)
        )
    }

    private fun toAccountDomain(accountEntity: AccountEntity): Account {
        return Account(
            id = AccountId(accountEntity.accountId!!),
            balance = AccountBalance(accountEntity.balance)
        )
    }

    private fun toEntity(transaction: Transaction): TransactionEntity {
        return TransactionEntity(
            fromAccountId = transaction.fromAccount.id!!.value,
            toAccountId = transaction.toAccount.id!!.value,
            amount = transaction.amount.value
        )
    }
}
