package com.finmid.fintech.jpa.entities

import jakarta.persistence.Column
import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.Id
import jakarta.persistence.Table
import jakarta.persistence.Version
import java.math.BigDecimal
import java.util.UUID

@Entity
@Table(name = "account")
class AccountEntity(
    @Id
    @GeneratedValue
    @Column(name = "account_id", columnDefinition = "UUID")
    var accountId: UUID? = null,

    @Column(nullable = false)
    var balance: BigDecimal = BigDecimal.ZERO,

    @Version
    var version: Long? = null
)

