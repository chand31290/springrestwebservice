package com.finmid.fintech.application.accounts.dto

import com.finmid.fintech.domain.model.Account
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.UUID

data class AccountDto(
    val accountId: UUID,
    val balance: BigDecimal
) {
    init {
        balance.setScale(2, RoundingMode.HALF_UP)
    }
    companion object {
        fun from(account: Account): AccountDto {
            return AccountDto(
                accountId = account.id!!.value,
                balance = account.getBalance().value.setScale(2, RoundingMode.HALF_UP)
            )
        }
    }
}
