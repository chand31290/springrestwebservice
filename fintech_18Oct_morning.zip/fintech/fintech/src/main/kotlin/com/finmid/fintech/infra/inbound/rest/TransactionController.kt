package com.finmid.fintech.infra.inbound.rest

import com.finmid.fintech.application.transaction.CreateTransactionUseCase
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.media.Content
import io.swagger.v3.oas.annotations.media.Schema
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import io.swagger.v3.oas.annotations.parameters.RequestBody as SwaggerRequestBody
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import java.math.BigDecimal
import java.util.UUID

@RestController
@RequestMapping("/transactions")
class TransactionController(
    private val createTransactionUseCase: CreateTransactionUseCase
) {

    @Operation(summary = "Create a transaction between two accounts")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "201", description = "Transaction created successfully"),
            ApiResponse(responseCode = "400", description = "Invalid request", content = [Content()]),
            ApiResponse(responseCode = "404", description = "Account not found", content = [Content()])
        ]
    )
    @PostMapping
    fun createTransaction(
        @SwaggerRequestBody(description = "Transaction details", required = true,
            content = [Content(schema = Schema(implementation = CreateTransactionRequest::class))])
        @RequestBody request: CreateTransactionRequest
    ): ResponseEntity<String> = with(request) {
        createTransactionUseCase(
            fromAccountId = fromAccountId,
            toAccountId = toAccountId,
            amount = amount
        )
        return ResponseEntity.status(HttpStatus.CREATED).body("Transaction created successfully.")
    }
}

data class CreateTransactionRequest(
    val fromAccountId: UUID,
    val toAccountId: UUID,
    val amount: BigDecimal
)
