package com.finmid.fintech.domain.exception

import java.lang.Exception

data class InsufficientBalanceException(val reason: String) : Exception()
