package com.finmid.fintech.domain.model

import java.math.BigDecimal

data class TransactionAmount(val value: BigDecimal){
    init {
        require(value > BigDecimal.ZERO) { "Transaction amount must be positive" }
    }
}
