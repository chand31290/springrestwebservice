package com.finmid.fintech.application.accounts

import com.finmid.fintech.application.accounts.dto.AccountDto
import com.finmid.fintech.domain.exception.AccountNotFoundException
import com.finmid.fintech.domain.model.AccountId
import com.finmid.fintech.domain.repository.AccountRepository
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional

@Service
class FetchAccountBalanceUseCase(
    private val accountRepository: AccountRepository
) {

    @Transactional(readOnly = true)
    operator fun invoke(accountId: AccountId) : AccountDto {
        val account = accountRepository.findById(accountId)
            .orElseThrow { AccountNotFoundException("Account not found") }

        return  AccountDto.from(account)
    }
}