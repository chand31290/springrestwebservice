package com.finmid.fintech.domain.model

data class Account(
    val id: AccountId? = null,
    private var balance: AccountBalance
) {
    init {
        require(!balance.isNegative()) { "Initial balance cannot be negative" }
    }

    fun getBalance(): AccountBalance = balance

    internal fun debit(amount: TransactionAmount) {
        balance = balance.subtract(amount)
    }

    internal fun credit(amount: TransactionAmount) {
        balance = balance.add(amount)
    }
}
