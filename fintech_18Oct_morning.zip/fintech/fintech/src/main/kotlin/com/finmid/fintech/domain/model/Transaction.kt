package com.finmid.fintech.domain.model

data class Transaction(
    val transactionId: TransactionId?=null,
    val fromAccount: Account,
    val toAccount: Account,
    val amount: TransactionAmount
) {
    init {
        require(fromAccount.id != toAccount.id) {
            "Transaction cannot happen between the same account"
        }
    }

    fun execute() {
        fromAccount.debit(amount)
        toAccount.credit(amount)
    }
}

