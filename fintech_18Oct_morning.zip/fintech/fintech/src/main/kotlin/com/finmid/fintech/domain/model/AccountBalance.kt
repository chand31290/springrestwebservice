package com.finmid.fintech.domain.model

import com.finmid.fintech.domain.exception.InsufficientBalanceException
import java.math.BigDecimal

data class AccountBalance(val value: BigDecimal) {
    init {
        require(value >= BigDecimal.ZERO) { "Balance cannot be negative" }
    }

    fun add(amount: TransactionAmount): AccountBalance {
        return AccountBalance(this.value + amount.value)
    }

    fun subtract(amount: TransactionAmount): AccountBalance {
        val newBalance = this.value - amount.value
        if (newBalance < BigDecimal.ZERO) {
            throw InsufficientBalanceException("Insufficient funds after transaction")
        }
        return AccountBalance(newBalance)
    }

    fun isNegative(): Boolean = value < BigDecimal.ZERO
}
