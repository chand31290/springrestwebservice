package com.finmid.fintech.domain.repository

import com.finmid.fintech.domain.model.Transaction
import com.finmid.fintech.domain.model.TransactionId
import java.util.Optional

interface TransactionRepository {
    fun save(transaction: Transaction): Transaction
    fun findById(transactionId: TransactionId): Optional<Transaction>
}