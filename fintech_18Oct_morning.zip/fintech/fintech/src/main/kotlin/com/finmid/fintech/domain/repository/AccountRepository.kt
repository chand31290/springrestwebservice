package com.finmid.fintech.domain.repository

import com.finmid.fintech.domain.model.Account
import com.finmid.fintech.domain.model.AccountId
import java.util.Optional

interface AccountRepository {
    fun findById(accountId: AccountId): Optional<Account>
    fun save(account: Account): Account
}