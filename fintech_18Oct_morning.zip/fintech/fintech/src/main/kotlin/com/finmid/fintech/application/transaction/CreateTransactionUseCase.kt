package com.finmid.fintech.application.transaction

import com.finmid.fintech.domain.model.AccountId
import com.finmid.fintech.domain.service.TransactionService
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.math.BigDecimal
import java.util.UUID

@Service
class CreateTransactionUseCase(
    private val transactionService: TransactionService
) {

    @Transactional
    operator fun invoke(fromAccountId: UUID, toAccountId: UUID, amount: BigDecimal) =
        transactionService.processTransaction(
            fromAccountId = AccountId(fromAccountId),
            toAccountId = AccountId(toAccountId),
            amount = amount
        )
}
