package com.finmid.fintech.application.accounts

import com.finmid.fintech.application.accounts.dto.AccountDto
import com.finmid.fintech.domain.model.Account
import com.finmid.fintech.domain.model.AccountBalance
import com.finmid.fintech.domain.repository.AccountRepository
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.math.BigDecimal

@Service
class CreateAccountUseCase(
    private val accountRepository: AccountRepository
) {

    @Transactional
    operator fun invoke(initialBalance: BigDecimal?) : AccountDto{
        val balance = initialBalance?.let {
            AccountBalance(it)
        } ?: AccountBalance(BigDecimal.ZERO)

        val newAccount = Account(id = null, balance)
        val createdAccount = accountRepository.save(newAccount)
        return AccountDto.from(createdAccount)
    }
}