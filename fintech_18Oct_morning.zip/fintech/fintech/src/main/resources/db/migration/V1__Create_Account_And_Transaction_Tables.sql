CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create Account Table
CREATE TABLE account (
    account_id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    balance NUMERIC NOT NULL
);

-- Create Transaction Table
CREATE TABLE transaction (
    transaction_id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    from_account_id UUID NOT NULL,
    to_account_id UUID NOT NULL,
    amount NUMERIC NOT NULL,
    created_at TIMESTAMP NOT NULL,

    CONSTRAINT fk_from_account FOREIGN KEY (from_account_id) REFERENCES account (account_id),
    CONSTRAINT fk_to_account FOREIGN KEY (to_account_id) REFERENCES account (account_id)
);
